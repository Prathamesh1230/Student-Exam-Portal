class Exam:
    def __init__(self, exam_code, subject):
        self.code = exam_code
        self.subject = subject
