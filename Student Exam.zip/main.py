from exam_controller import ExamController

def main():
    controller = ExamController()
    controller.start_portal()

if __name__ == "__main__":
    main()
