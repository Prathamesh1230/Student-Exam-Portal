def is_valid_marks(marks):
    return 0 <= marks <= 100